##############
## HD level ##
##############

# Create some utility functions 

# State the Null Hypothesis and the Alternative Hypothesis
hypothesis <- function(file_name){
  cat("*The script is going to read the file", file_name, "and perform a linear regression with custom output. The assumption is that the file containing the data set is a csv file with two named columns, a predictor and an outcome, in this order.*\n\n\n", sep=" ")
  x_file <- read.csv(file_name)
  x <- x_file[,1]
  name_x <- names(x_file[1])
  y <- x_file[,2]
  name_y <- names(x_file[2])
  fit0 <- lm(y ~ x)
  cat("HYPOTHESIS\nThe null hypothesis H0 is beta=0, and the alternative hypothesis H1 is beta different from 0. beta is the true slope parameter as in the model ",name_y," = alpha + beta ", name_x, " + epsilon.\n\n", sep="")
}

# Check the assumptions, plotting (a) y vs x, (b) the scatter plot of the regression residuals ei vs the fitted values ŷ and (c) the histogram of the regression residuals ei. Only 3 graphs are required for this point, there is no need to comment.
assumptions <- function(file_name){
  cat("ASSUMPTIONS\nPlease check the plots.\n")
  x_file <- read.csv(file_name)
  x <- x_file[,1]
  name_x <- names(x_file[1])
  y <- x_file[,2]
  name_y <- names(x_file[2])
  fit0 <- lm(y ~ x)
  par(mfrow=c(3,1))
  plot(x, y, main=paste("Scatterplot of ",name_y," vs ",name_x, sep=""), xlab=name_x, ylab=name_y)
  plot(fit0$fitted.values, fit0$residuals, main="Scatterplot of fitted values vs residuals", xlab="Fitted values", ylab="Residuals")
  hist(fit0$residuals, main="Histogram of residuals", xlab="Residuals")
  par(mfrow=c(1,1))
}

# Perform the linear regression and report the values of the estimated slope β̂, the 95% CIs for β̂, the value of t, the degree of freedom df, and the p-value.
fit <- function(file_name){
  x_file <- read.csv(file_name)
  x <- x_file[,1]
  name_x <- names(x_file[1])
  y <- x_file[,2]
  name_y <- names(x_file[2])
  fit0 <- lm(y ~ x)
  
  # Shortcut: using summary(fit0), or students can compute all the required results
  summ_fit0 <- summary(fit0)
  # str(summ_fit0)
  estimates <- summ_fit0$coefficients[2,]
  # str(estimates)
  beta_hat <- estimates[1]
  st.err <- estimates[2]
  t_val <- estimates[3]
  p_val <- estimates[4]
  df <- summ_fit0$df[2]
  cv <- qt(p = 0.975, df = df)
  CI95 <- c(beta_hat-cv*st.err, beta_hat+cv*st.err)
  cat("\nFIT - Linear regression\n")
  cat("Results:\n")
  cat("beta_hat = ", beta_hat, "\n")
  cat("95% CI = (", CI95[1], ", ", CI95[2], ")\n", sep="")
  cat("t_value = ", t_val, "\n")
  cat("df = ", df, "\n")
  cat("p_value = ", p_val, "\n\n")
  # Create output object 
  myfit <- list(beta_hat = beta_hat, p_val = p_val, name_x = name_x, name_y = name_y)
  class(myfit) <- "mylm"
  return(myfit)
}

# Write the “decision” of the test, either rejection or not rejection of the Null Hypothesis, at 5% significance level.

decision <- function(x, ...){
  UseMethod("decision")
}

decision.mylm <- function(myfit){
  cat("DECISION\n")
  p_val <- myfit$p_val
  if (p_val>=0.05) {
    decision <- "Do not reject NULL hypothesis"
  } else {
    decision <- "Reject NULL hypothesis"
  }
  cat(decision, "\n\n")
}

# Write a conclusion to the test, i.e., one or two sentences in English in which you explain the results and describe the relationship or lack of relationship between X and Y.
conclusion <- function(x, ...){
  UseMethod("conclusion")
}

conclusion.mylm <- function(myfit){
  beta_hat <- myfit$beta_hat
  p_val <- myfit$p_val
  name_x <- myfit$name_x
  name_y <- myfit$name_y
  cat("CONCLUSION\n")
  if (p_val>=0.05) {
    conclusion <- paste("There is no evidence that the slope (beta) is different than 0. There is no significant linear relationship between ", name_x, " and ", name_y, ".", sep="")
  } else {
    if (beta_hat>0) {
      conclusion <- paste("There is evidence that the slope (beta) is different than 0. There is a significant linear relationship between ", name_x, " and ", name_y, ". For each unit-increase in ", name_x, ", ", name_y, " increases by ", beta_hat, ".", sep="")
    } else {
      conclusion <- paste("There is evidence that the slope (beta) is different than 0. There is a significant linear relationship between ", name_x, " and ", name_y, ". For each unit-increase in ", name_x, ", ", name_y, " decreases by ", round(abs(beta_hat), 4), ".", sep="")
    }
  }
  cat(conclusion, "\n")
}


mytest <- function(file_name){
  hypothesis(file_name)
  assumptions(file_name)
  myfit <- fit(file_name)
  decision(myfit)
  conclusion(myfit)
}

######################
# Run functions

# read the files “A3_Ex3_signif.csv” and “A3_Ex3_not_signif.csv”. Uncomment only one.
file_name <- "A3_Ex3_signif.csv" 
# file_name <- "A3_Ex3_not_signif.csv" 

mytest(file_name)
