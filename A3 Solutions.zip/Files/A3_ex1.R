# Read the file “A3_Ex1.csv” in a data frame X
X <- read.csv("A3_Ex1.csv")
# Show the structure of X (str(X))
str(X)
# Compute and show the total sum of the expenditures
sum(X$expenditure)
# Compute and show the sum of the expenditures in January
sum(X$expenditure[X$month=="Jan"])
# Compute and show the sum of the expenditures in January when the weather is sunny
sum(X$expenditure[X$month=="Jan" & X$weather=="sunny"])
# Find and show the month with the highest expenditure
months <- labels(table(X$month))[[1]]

# Solution 1
max_expenditure <- NULL
for (mo in months){
  max_expenditure <- c(max_expenditure, max(X$expenditure[X$month==mo]))
}
top_expenditure <- max(max_expenditure)
i_months <- which(max_expenditure == top_expenditure)
months_with_max_expenditure <- months[i_months]
print(months_with_max_expenditure)


# Solution 2 (does not deal well if there are multiple months with the same top expense)
max_expenditure <- NULL
for (mo in months){
  max_expenditure <- c(max_expenditure, max(X$expenditure[X$month==mo]))
}
month_with_max_expenditure <- months[which.max(max_expenditure)]
print(month_with_max_expenditure)

# Solution 3 (ie alternative solution, there are many of course. Again it does not deal well if there are multiple months with the same top expense)
month_with_max_expenditure <- months[1]
max_expenditure_current <-  max(X$expenditure[X$month==months[1]])
for (mo in months[2:length(months)]){
  max_expenditure <- max(X$expenditure[X$month==mo])
  if (max_expenditure > max_expenditure_current){
    month_with_max_expenditure <- mo
    max_expenditure_current <- max_expenditure
  }
}
print(month_with_max_expenditure)