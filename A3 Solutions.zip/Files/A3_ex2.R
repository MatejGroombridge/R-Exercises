# Run set.seed(1024)
set.seed(1024)
# Create a list X with N=100 slots, and in each slot create a list of two elements:
#   * name, along the lines of “n1”, “n2”, “n3”, …, “n100”
#   * vect, a numeric vector of 5 elements sampled from a normal distribution with μ=23 and σ=5.
X <- lapply(1:100, function(i){list(name=paste("n", i, sep=""), vect=rnorm(n = 5, mean = 23, sd = 5))})
# Show the structure of X (str(X)).
str(X)
# Compute the sum of the values of vect in each slot and show the output. The output must be a vector of 100 values.
sapply(X, function(xi) sum(xi$vect))
# Create a matrix M (not a data frame) of size 100x5 using the 100 vect objects in the slots of X.
M <- sapply(X, function(xi) xi$vect, simplify = TRUE)
M=t(M)
str(M)
# Use a for cycle to compute the sums by columns of M and show the result.
for (i in 1:5){
  print(sum(M[,i]))
}
