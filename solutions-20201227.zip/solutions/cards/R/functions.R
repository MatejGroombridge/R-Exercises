# Teach R about the new methods in towm
# We do not need many info here, #'export is enough
#' @export
add_card <- function(x, ...){
  UseMethod("add_card")
}

#' @export
list_cards <- function(x, ...){
  UseMethod("list_cards")
}

#' @export
del_card <- function(x, ...){
  UseMethod("del_card")
}

#' @export
search_card <- function(x, ...){
  UseMethod("search_card")
}

##################################################
##################################################
##################################################


## Functions and methods

#' Function: create a new card
#'
#' This function allows you to create a new object of class "card"
#' @param name The person name
#' @param age The person age
#' @param langs The languages spoken by the person. Defaults to NULL.
#' @param cols The person's favourite colours. Defaults to NULL.
#' @keywords card
#' @export
#' @examples
#' # Create some cards
#' bob_card = new_card(name="Bob", age=23, langs=c("English", "Mandarin"), cols=c("red", "blue"))
#' mary_card = new_card(name="Mary", age=27, langs=c("English"), cols=c("red", "blue", "yellow"))
#' bruce_card = new_card(name="Bruce", age=18)
#' # Have a look at the cards (these really invoke print())
#' bob_card
#' mary_card
#' bruce_card

new_card <- function(name, age, langs=NULL, cols=NULL){
  card = list(name= name, age= age, langs= langs, cols= cols)
  class(card) <- "card"
  # Output
  card
}

#' Method to print card
#'
#' This function allows you to print an  object of class "card"
#' @param card The card to print
#' @keywords card
#' @export
#' @examples
#' # Create some cards
#' bob_card = new_card(name="Bob", age=23, langs=c("English", "Mandarin"), cols=c("red", "blue"))
#' mary_card = new_card(name="Mary", age=27, langs=c("English"), cols=c("red", "blue", "yellow"))
#' bruce_card = new_card(name="Bruce", age=18)
#' # Have a look at the cards (these really invoke print())
#' print(bob_card)
#' print(mary_card)
#' print(bruce_card)

print.card <- function(card){
  # Deal with the number of languages
  if (length(card$langs)==0){
    langs_msg = "cannot speak any language (believe it or not!)"
  } else if (length(card$langs)==1){
    langs_msg = paste("can speak", card$langs)
  } else if (length(card$langs)==2){
    langs_msg = paste("can speak", card$langs[1], "and", card$langs[2])
  } else if (length(card$langs)>3){
    # We can collapse the first k-1 elements of a character k-vector using lang[-length(langs)]
    langs_str = paste(card$langs[-length(card$langs)], collapse=", ")
    # And then we add the last language separated by "and"
    langs_str = paste(langs_str, "and", card$langs[length(card$langs)])
    langs_msg = paste("can speak", langs_str)
  }
  # Deal with the number of colours
  if (length(card$cols)==0){
    cols_msg = "does not like any colour (so sad)"
  } else if (length(card$cols)==1){
    cols_msg = paste("likes", card$cols)
  } else if (length(card$cols)==2){
    cols_msg = paste("likes", card$cols[1], "and", card$cols[2])
  } else if (length(card$cols)>=3){
    # We can collapse the first k-1 elements of a character k-vector using lang[-length(cols)]
    cols_str = paste(card$cols[-length(card$cols)], collapse=", ")
    # And then we add the last language separated by "and"
    cols_str = paste(cols_str, "and", card$cols[length(card$cols)])
    cols_msg = paste("likes", cols_str)
  }
  # Show message
  cat(card$name, ", ", card$age, ", ", langs_msg, " and ", cols_msg, ".\n", sep="")
}

#' Create a new cabinet
#'
#' This function allows you to create a new object of class "cabinet"
#' @keywords cabinet
#' @export
#' @examples
#' # Create a new cabinet
#' cc=new_cabinet()
#' str(cc)

new_cabinet <- function(){
  cab <- list(cards=NULL, max_serial=0)
  class(cab) <- "cabinet"
  cab
}


#' Method: add a card to a cabinet
#'
#' This function allows you to add a "card" to a "cabinet"
#' @param cabinet A cabinet
#' @param card A card to add to the cabinet
#' @keywords card, cabinet
#' @export
#' @examples
#' # Create some cards
#' bob_card = new_card(name="Bob", age=23, langs=c("English", "Mandarin"), cols=c("red", "blue"))
#' mary_card = new_card(name="Mary", age=27, langs=c("English"), cols=c("red", "blue", "yellow"))
#' bruce_card = new_card(name="Bruce", age=18)
#' # Have a look at the cards (these really invoke print())
#' bob_card
#' mary_card
#' bruce_card
#' # Create a new cabinet
#' cc=new_cabinet()
#' # Add, list, delete cards
#' cc <- add_card(cc, bob_card)
#' cc <- add_card(cc, mary_card)
#' cc <- add_card(cc, bruce_card)
#' str(cc)

add_card.cabinet <- function(cabinet, card){
  cabinet$max_serial <- cabinet$max_serial + 1
  card_id <- paste("c", cabinet$max_serial, sep="")
  cabinet$cards <- c(cabinet$cards, list(card))
  # check the length of cabinet$cards
  ll <- length(cabinet$cards)
  # name the last card
  names(cabinet$cards)[ll] <- card_id
  cabinet
}


#' Method: list all card_ids in the cabinet
#'
#' This function allows you to list all the card_ids of the "card" objects in a "cabinet"
#' @param cabinet A cabinet
#' @keywords card, cabinet
#' @export
#' @examples
#' # Create some cards
#' bob_card = new_card(name="Bob", age=23, langs=c("English", "Mandarin"), cols=c("red", "blue"))
#' mary_card = new_card(name="Mary", age=27, langs=c("English"), cols=c("red", "blue", "yellow"))
#' bruce_card = new_card(name="Bruce", age=18)
#' # Have a look at the cards (these really invoke print())
#' bob_card
#' mary_card
#' bruce_card
#' # Create a new cabinet
#' cc=new_cabinet()
#' # Add, list, delete cards
#' cc <- add_card(cc, bob_card)
#' cc <- add_card(cc, mary_card)
#' cc <- add_card(cc, bruce_card)
#' str(cc)
#' list_cards(cc)

list_cards.cabinet <- function(cabinet){
  print(names(cabinet$cards))
}


#' Method: delete a card from a cabinet
#'
#' This function allows you to delete a "card" with a specified card_id from a "cabinet"
#' @param cabinet A cabinet
#' @param card_id A card_id
#' @keywords card, cabinet
#' @export
#' @examples
#' # Create some cards
#' bob_card = new_card(name="Bob", age=23, langs=c("English", "Mandarin"), cols=c("red", "blue"))
#' mary_card = new_card(name="Mary", age=27, langs=c("English"), cols=c("red", "blue", "yellow"))
#' bruce_card = new_card(name="Bruce", age=18)
#' # Have a look at the cards (these really invoke print())
#' bob_card
#' mary_card
#' bruce_card
#' # Create a new cabinet
#' cc=new_cabinet()
#' # Add, list, delete cards
#' cc <- add_card(cc, bob_card)
#' cc <- add_card(cc, mary_card)
#' cc <- add_card(cc, bruce_card)
#' str(cc)
#' list_cards(cc)
#' cc <- del_card(cc, "c3")
#' str(cc)
#' list_cards(cc)

del_card.cabinet <- function(cabinet, card_id){
  idel <- which(card_id == names(cabinet$cards))
  if (length(idel) == 0) stop("Something went wrong, there are no cards with card_id =", card_id)
  if (length(idel) > 1) stop("Something went wrong, there are 2 or more cards with card_id =", card_id)
  cabinet$cards <- cabinet$cards[-idel]
  cabinet
}


#' Method: search cards in a cabinet
#'
#' This function allows you to search all the "card" objects in a "cabinet" and find those relative to persons with age in a specified interval
#' @param cabinet A cabinet
#' @param age_min The lower bound of the age interval (included)
#' @param age_max The upper bound of the age interval (included)
#' @keywords card, cabinet, search
#' @export
#' @examples
#' # Create some cards
#' bob_card = new_card(name="Bob", age=23, langs=c("English", "Mandarin"), cols=c("red", "blue"))
#' mary_card = new_card(name="Mary", age=27, langs=c("English"), cols=c("red", "blue", "yellow"))
#' bruce_card = new_card(name="Bruce", age=18)
#' # Have a look at the cards (these really invoke print())
#' bob_card
#' mary_card
#' bruce_card
#' # Create a new cabinet
#' cc=new_cabinet()
#' # Add, list, delete cards
#' cc <- add_card(cc, bob_card)
#' cc <- add_card(cc, mary_card)
#' cc <- add_card(cc, bruce_card)
#' # Search cards
#' search_card(cc, 21,25)
#' search_card(cc, 21,28)
#' search_card(cc, 21,27)

search_card.cabinet <- function(cabinet, age_min, age_max){
  # Extract all ages
  ages <- sapply(cabinet$cards, function(card)card$age)
  # Find the indexes of ages (and cards) that satisfy the condition
  isel <- which(ages >= age_min & ages <= age_max)
  # Extract all names
  names <- sapply(cabinet$cards, function(card)card$name)
  # Extract all card_ids
  card_ids <- names(cabinet$cards)
  # Return a data frame of the selected cards
  data.frame(card_id = card_ids[isel], name = names[isel], age = ages[isel])
}
